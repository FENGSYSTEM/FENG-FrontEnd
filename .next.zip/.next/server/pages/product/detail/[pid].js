module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../../../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 10);
/******/ })
/************************************************************************/
/******/ ({

/***/ "+wlD":
/***/ (function(module, exports) {

module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 10:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("Rm66");


/***/ }),

/***/ "2Sww":
/***/ (function(module, exports) {



/***/ }),

/***/ "4Q3z":
/***/ (function(module, exports) {

module.exports = require("next/router");

/***/ }),

/***/ "E55Z":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return API_ENDPOINT; });
const API_ENDPOINT = "https://api.fengsystem.co/api"; // export const API_ENDPOINT = "http://103.163.119.161:10000/api";

/***/ }),

/***/ "Exp3":
/***/ (function(module, exports) {

module.exports = require("antd");

/***/ }),

/***/ "F5FC":
/***/ (function(module, exports) {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ "GUTJ":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return SizeChartPants; });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("F5FC");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("Exp3");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);



function SizeChartPants({}) {
  const columns = [{
    title: "",
    dataIndex: "name"
  }, {
    title: "Length",
    dataIndex: "size1"
  }, {
    title: "Waist",
    dataIndex: "size2"
  }, {
    title: "Rise",
    dataIndex: "size3"
  }, {
    title: "Thigh",
    dataIndex: "size4"
  }];
  const data = [{
    key: "1",
    name: "Small",
    size1: "100 cm",
    size2: "30 cm",
    size3: "35 cm",
    size4: "32 cm"
  }, {
    key: "2",
    name: "Medium",
    size1: "110 cm",
    size2: "33 cm",
    size3: "35 cm",
    size4: "32 cm"
  }, {
    key: "3",
    name: "Large",
    size1: "110 cm",
    size2: "38 cm",
    size3: "35 cm",
    size4: "32 cm"
  }, {
    key: "4",
    name: "Extra Large",
    size1: "110 cm",
    size2: "40 cm",
    size3: "35 cm",
    size4: "32 cm"
  }];
  return /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])(antd__WEBPACK_IMPORTED_MODULE_1__["Table"], {
    columns: columns,
    dataSource: data,
    pagination: false // showHeader={false}
    ,
    bordered: true
  });
}

/***/ }),

/***/ "Rm66":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return index; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getServerSideProps", function() { return getServerSideProps; });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("F5FC");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("Exp3");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_SizeChartLogoT__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("rfGd");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("4Q3z");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("h74D");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _redux_slices_api_orderSlice__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__("ZMeN");
/* harmony import */ var react_image_gallery_styles_css_image_gallery_css__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__("2Sww");
/* harmony import */ var react_image_gallery_styles_css_image_gallery_css__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_image_gallery_styles_css_image_gallery_css__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_image_gallery__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__("UMQD");
/* harmony import */ var react_image_gallery__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_image_gallery__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var dompurify__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__("ycSr");
/* harmony import */ var dompurify__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(dompurify__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__("xnum");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _components_SizeChartPants__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__("GUTJ");
/* harmony import */ var _components_SizeChartTankTop__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__("vWIC");
/* harmony import */ var _components_SizeChartRugs__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__("kSR9");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__("zr5I");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var src_utils_constant_api__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__("E55Z");




function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }







// import AliceCarousel from "react-alice-carousel";
// import "react-alice-carousel/lib/alice-carousel.css";









function index({
  pid,
  detailData
}) {
  const route = Object(next_router__WEBPACK_IMPORTED_MODULE_4__["useRouter"])();
  const dispatch = Object(react_redux__WEBPACK_IMPORTED_MODULE_5__["useDispatch"])();
  const {
    0: DOMPurify,
    1: setDOMPurify
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])();
  const {
    0: wd,
    1: setWd
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])();
  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(() => {
    if (window) {
      setWd(window);
      setDOMPurify(dompurify__WEBPACK_IMPORTED_MODULE_9___default()(window));
    }
  }, []);
  const {
    0: sizeValue,
    1: setSizeValue
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])();
  const {
    0: colorValue,
    1: setColorValue
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])();
  const productDetail = Object(react_redux__WEBPACK_IMPORTED_MODULE_5__["useSelector"])(state => state.product.productDetail);
  const {
    0: thumbs,
    1: setThumbs
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(); // useEffect(() => {
  //   console.log(route.query.pid);
  //   const a = async () => {
  //     await dispatch(getProductDetail(route.query.pid));
  //   };
  //   a();
  // }, [route.query]);

  const SizeSelector = ({
    size
  }) => {
    return /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("div", {
      className: `product-detail-selector-item ${sizeValue === size && "active"}`,
      onClick: () => setSizeValue(size),
      children: size
    });
  };

  function c_hex_is_light(color) {
    const hex = color.replace("#", "");
    const c_r = parseInt(hex.substr(0, 2), 16);
    const c_g = parseInt(hex.substr(2, 2), 16);
    const c_b = parseInt(hex.substr(4, 2), 16);
    const brightness = (c_r * 299 + c_g * 587 + c_b * 114) / 1000;
    return brightness > 155;
  }

  const ColorSelector = ({
    color
  }) => {
    const {
      0: hover,
      1: setHover
    } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(false);
    return /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("div", {
      onMouseEnter: () => setHover(true),
      onMouseLeave: () => setHover(false),
      className: `product-detail-selector-item`,
      style: {
        backgroundColor: hover ? color.color_code : colorValue === color.color_code ? color.color_code : "#ffffff",
        color: hover ? c_hex_is_light(color.color_code) ? "#000000" : "#ffffff" : colorValue === color.color_code ? c_hex_is_light(color.color_code) ? "#000000" : "#ffffff" : "#000000"
      },
      onClick: () => setColorValue(color.color_code),
      children: color.color_name
    });
  };

  const handleAddToCart = () => {
    if (detailData.status === "IN_STOCK") {
      if (sizeValue && colorValue) {
        const selectedProduct = {
          id: route.query.pid,
          name: detailData.name,
          price: detailData.price,
          size: sizeValue,
          color: colorValue,
          amount: 1
        };
        console.log(selectedProduct);

        if (localStorage.getItem("cart")) {
          let listProductInCart = JSON.parse(localStorage.getItem("cart"));
          const existingProductIndex = listProductInCart.findIndex(e => e.id === selectedProduct.id && e.size === selectedProduct.size && e.color === selectedProduct.color);

          if (existingProductIndex !== -1) {
            let existingProduct = listProductInCart[existingProductIndex];
            listProductInCart[existingProductIndex] = _objectSpread(_objectSpread({}, existingProduct), {}, {
              amount: existingProduct.amount + 1
            });
            localStorage.setItem("cart", JSON.stringify(listProductInCart));
            dispatch(Object(_redux_slices_api_orderSlice__WEBPACK_IMPORTED_MODULE_6__[/* updateCart */ "c"])(listProductInCart));
            antd__WEBPACK_IMPORTED_MODULE_2__["message"].info("Added to cart");
          } else {
            listProductInCart.push(selectedProduct);
            localStorage.setItem("cart", JSON.stringify(listProductInCart));
            dispatch(Object(_redux_slices_api_orderSlice__WEBPACK_IMPORTED_MODULE_6__[/* updateCart */ "c"])(listProductInCart));
            antd__WEBPACK_IMPORTED_MODULE_2__["message"].info("Added to cart");
          }
        } else {
          const listProductInCart = [];
          listProductInCart.push(selectedProduct);
          localStorage.setItem("cart", JSON.stringify(listProductInCart));
          dispatch(Object(_redux_slices_api_orderSlice__WEBPACK_IMPORTED_MODULE_6__[/* updateCart */ "c"])(listProductInCart));
          antd__WEBPACK_IMPORTED_MODULE_2__["message"].info("Added to cart");
        }
      } else {
        antd__WEBPACK_IMPORTED_MODULE_2__["message"].info("Please select size or color");
      }
    } else {
      antd__WEBPACK_IMPORTED_MODULE_2__["message"].info("This product is out of stock !!");
    }
  };

  const DescriptionHTML = detailData.description;
  console.log(detailData.images.map((url, index) => ({
    original: url,
    thumbnail: url
  })));
  return /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxs"])(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: [/*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxs"])(next_head__WEBPACK_IMPORTED_MODULE_10___default.a, {
      children: [/*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxs"])("title", {
        children: [detailData.name, " - FENGSYSTEM"]
      }), /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("meta", {
        "http-equiv": "Content-Type",
        content: "text/html; charset=UTF-8"
      }), /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("meta", {
        property: "og:title",
        content: `${detailData.name} / FENG SS22 - EMBODY`
      }), /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("meta", {
        name: "og:description",
        content: `Discover all the collections by Feng for women, men and browse the Feng 's system and heritage`
      }), /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("meta", {
        name: "description",
        content: `Discover all the collections by Feng for women, men and browse the Feng 's system and heritage`
      }), /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("meta", {
        property: "og:url",
        content: `https://fengsystem.co/product/detail/${pid}/`
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"]("link", {
        rel: "canonical",
        href: `https://fengsystem.co/product/detail/${pid}/`
      }), /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("meta", {
        property: "og:image",
        content: detailData.images[0]
      }), /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("meta", {
        property: "og:type",
        content: "article"
      }), /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("meta", {
        name: "robots",
        content: "index, follow"
      })]
    }), /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("div", {
      className: "col-12",
      children: /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxs"])("div", {
        className: "row",
        children: [/*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("div", {
          className: "col-md-5",
          children: detailData.images && /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])(react_image_gallery__WEBPACK_IMPORTED_MODULE_8___default.a, {
            showNav: false,
            showPlayButton: false,
            showFullscreenButton: false,
            items: detailData.images.map((url, index) => ({
              original: url,
              thumbnail: url,
              originalWidth: "100%"
            }))
          })
        }), /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxs"])("div", {
          className: "col-md-7",
          children: [/*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("h4", {
            className: "",
            children: detailData.name
          }), /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxs"])("h4", {
            className: "font-bold",
            children: ["$", detailData.price]
          }), /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("div", {
            className: "my-4",
            children: wd && /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("div", {
              dangerouslySetInnerHTML: {
                __html: DOMPurify.sanitize(DescriptionHTML)
              }
            })
          }), /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxs"])("div", {
            className: "my-3",
            children: [/*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxs"])("div", {
              className: "my-3",
              children: [/*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("h6", {
                children: /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("u", {
                  children: "SELECT A SIZE"
                })
              }), /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("div", {
                className: "d-flex product-detail-size",
                children: detailData.productStocks.map((obj, index) => /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])(SizeSelector, {
                  size: obj.size
                }, `key-${index}`))
              })]
            }), /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxs"])("div", {
              className: "my-3",
              children: [/*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("h6", {
                children: /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("u", {
                  children: "SELECT A COLOR"
                })
              }), /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("div", {
                className: "d-flex product-detail-size",
                children: detailData.color.map((color, index) => /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])(ColorSelector, {
                  color: color
                }))
              })]
            }), /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("div", {
              className: "my-4",
              children: /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("div", {
                className: "feng-button w-100",
                onClick: () => handleAddToCart(),
                children: "ADD TO CART"
              })
            })]
          }), /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("br", {}), /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("h6", {
            children: /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("u", {
              children: "Logo T"
            })
          }), /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])(_components_SizeChartLogoT__WEBPACK_IMPORTED_MODULE_3__["default"], {}), /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("br", {}), /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("br", {}), /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("h6", {
            children: /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("u", {
              children: "Pants"
            })
          }), /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])(_components_SizeChartPants__WEBPACK_IMPORTED_MODULE_11__["default"], {}), /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("br", {}), /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("br", {}), /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("h6", {
            children: /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("u", {
              children: "Tank Top"
            })
          }), /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])(_components_SizeChartTankTop__WEBPACK_IMPORTED_MODULE_12__["default"], {}), /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("br", {}), /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("br", {}), /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("h6", {
            children: /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("u", {
              children: "Rugs"
            })
          }), /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])(_components_SizeChartRugs__WEBPACK_IMPORTED_MODULE_13__["default"], {}), /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])("br", {})]
        })]
      })
    })]
  });
}
async function getServerSideProps(context) {
  const {
    pid
  } = context.query;
  const res = await axios__WEBPACK_IMPORTED_MODULE_14___default.a.get(`${src_utils_constant_api__WEBPACK_IMPORTED_MODULE_15__[/* API_ENDPOINT */ "a"]}/products/${pid}`);
  return {
    props: {
      pid,
      detailData: res.data
    } // will be passed to the page component as props

  };
}

/***/ }),

/***/ "UMQD":
/***/ (function(module, exports) {

module.exports = require("react-image-gallery");

/***/ }),

/***/ "ZMeN":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return createOrder; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return updateCart; });
/* unused harmony export emptyCart */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "d", function() { return updateTotalItems; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "e", function() { return updateTotalPrice; });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("+wlD");
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("Exp3");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("zr5I");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var src_utils_constant_api__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("E55Z");




const createOrder = Object(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__["createAsyncThunk"])("createOrder", async data => {
  const res = await axios__WEBPACK_IMPORTED_MODULE_2___default.a.post(`${src_utils_constant_api__WEBPACK_IMPORTED_MODULE_3__[/* API_ENDPOINT */ "a"]}/orders`, data);
  console.log(res.data);
  return res.data;
});
const initialState = {
  createOrderLoading: false,
  cart: [],
  totalItemsInCart: 0,
  totalPriceInCart: 0
};
const orderSlice = Object(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__["createSlice"])({
  name: "orderSlice",
  initialState,
  reducers: {
    updateCart: (state, {
      payload
    }) => {
      state.cart = payload;
    },
    emptyCart: state => {
      state.cart = [];
      state.totalItemsInCart = 0;
      state.totalPriceInCart = 0;
    },
    updateTotalItems: (state, {
      payload
    }) => {
      state.totalItemsInCart = payload;
    },
    updateTotalPrice: (state, {
      payload
    }) => {
      state.totalPriceInCart = payload;
    }
  },
  extraReducers: builder => {
    /**
     * @createOrder
     */
    builder.addCase(createOrder.pending, state => {
      state.createOrderLoading = true;
    });
    builder.addCase(createOrder.fulfilled, (state, {
      payload
    }) => {
      antd__WEBPACK_IMPORTED_MODULE_1__["message"].success("Order created !");
      state.createOrderLoading = false;
      state.cart = [];
      state.totalItemsInCart = 0;
      state.totalPriceInCart = 0;
      localStorage.removeItem("cart");
    });
    builder.addCase(createOrder.rejected, state => {
      state.createOrderLoading = false;
    });
  }
});
const {
  updateCart,
  emptyCart,
  updateTotalItems,
  updateTotalPrice
} = orderSlice.actions;
/* harmony default export */ __webpack_exports__["b"] = (orderSlice.reducer);

/***/ }),

/***/ "cDcd":
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "h74D":
/***/ (function(module, exports) {

module.exports = require("react-redux");

/***/ }),

/***/ "kSR9":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return SizeChartRugs; });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("F5FC");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("Exp3");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);



function SizeChartRugs({}) {
  const columns = [{
    title: "",
    dataIndex: "name"
  }, {
    title: "SIZE INFORMATION",
    dataIndex: "size1"
  }];
  const data = [{
    key: "1",
    name: "LOGO RUGS",
    size1: "51 cm X 51 cm"
  }, {
    key: "2",
    name: "BODY RUGS",
    size1: "170 cm x 42 cm"
  }];
  return /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])(antd__WEBPACK_IMPORTED_MODULE_1__["Table"], {
    columns: columns,
    dataSource: data,
    pagination: false,
    bordered: true
  });
}

/***/ }),

/***/ "rfGd":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return SizeChartLogoT; });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("F5FC");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("Exp3");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);



function SizeChartLogoT({}) {
  const columns = [{
    title: "",
    dataIndex: "name"
  }, {
    title: "Body Length",
    dataIndex: "size1"
  }, {
    title: "Chest Width",
    dataIndex: "size2"
  }, {
    title: "Neck Opening",
    dataIndex: "size3"
  }];
  const data = [{
    key: "1",
    name: "Small",
    size1: "70 cm",
    size2: "48 cm",
    size3: "21 cm"
  }, {
    key: "2",
    name: "Medium",
    size1: "72 cm",
    size2: "50 cm",
    size3: "21 cm"
  }, {
    key: "3",
    name: "Large",
    size1: "74 cm",
    size2: "52 cm",
    size3: "21 cm"
  }, {
    key: "3",
    name: "Extra Large",
    size1: "76 cm",
    size2: "54 cm",
    size3: "21 cm"
  }];
  return /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])(antd__WEBPACK_IMPORTED_MODULE_1__["Table"], {
    columns: columns,
    dataSource: data,
    pagination: false // showHeader={false}
    ,
    bordered: true
  });
}

/***/ }),

/***/ "vWIC":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return SizeChartTankTop; });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("F5FC");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("Exp3");
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);



function SizeChartTankTop({}) {
  const columns = [{
    title: "",
    dataIndex: "name"
  }, {
    title: "Body Length",
    dataIndex: "size1"
  }, {
    title: "Chest Width",
    dataIndex: "size2"
  }, {
    title: "Neck Opening",
    dataIndex: "size3"
  }];
  const data = [{
    key: "1",
    name: "Small",
    size1: "66 cm",
    size2: "25 cm",
    size3: "36 cm"
  }, {
    key: "2",
    name: "Medium",
    size1: "68 cm",
    size2: "25 cm",
    size3: "38 cm"
  }, {
    key: "3",
    name: "Large",
    size1: "70 cm",
    size2: "25 cm",
    size3: "40 cm"
  }, {
    key: "3",
    name: "Extra Large",
    size1: "72 cm",
    size2: "25 cm",
    size3: "42 cm"
  }];
  return /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])(antd__WEBPACK_IMPORTED_MODULE_1__["Table"], {
    columns: columns,
    dataSource: data,
    pagination: false // showHeader={false}
    ,
    bordered: true
  });
}

/***/ }),

/***/ "xnum":
/***/ (function(module, exports) {

module.exports = require("next/head");

/***/ }),

/***/ "ycSr":
/***/ (function(module, exports) {

module.exports = require("dompurify");

/***/ }),

/***/ "zr5I":
/***/ (function(module, exports) {

module.exports = require("axios");

/***/ })

/******/ });